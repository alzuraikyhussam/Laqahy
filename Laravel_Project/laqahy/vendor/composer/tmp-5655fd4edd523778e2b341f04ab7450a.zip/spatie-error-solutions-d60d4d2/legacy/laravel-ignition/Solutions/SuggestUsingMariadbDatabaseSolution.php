<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\SuggestUsingMariadbDatabaseSolution as BaseSuggestUsingMariadbDatabaseSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestUsingMariadbDatabaseSolution extends BaseSuggestUsingMariadbDatabaseSolutionAlias implements Solution
{

}
