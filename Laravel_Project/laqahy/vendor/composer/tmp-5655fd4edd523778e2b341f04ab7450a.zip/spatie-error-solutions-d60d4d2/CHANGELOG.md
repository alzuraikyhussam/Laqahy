# Changelog

All notable changes to `error-solutions` will be documented in this file.

## 1.0.0 - 2024-06-12

- Initial release

**Full Changelog**: https://github.com/spatie/error-solutions/compare/0.0.1...1.0.0

## 0.0.1 - 2024-06-11

**Full Changelog**: https://github.com/spatie/error-solutions/commits/0.0.1
